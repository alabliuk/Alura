# android-sync-parte-1

Projeto para o curso de sincronização com Web Service no Android
